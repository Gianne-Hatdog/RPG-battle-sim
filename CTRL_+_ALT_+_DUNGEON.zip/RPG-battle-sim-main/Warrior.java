public class Warrior extends Player {
    private int energy;
    private int maxEnergy;

    public Warrior(String name) {
        super(name, 120, 30, 15); // Base stats
        this.energy = 100;
        this.maxEnergy = 100;
    }

    public int getEnergy() { return energy; }
    public int getMaxEnergy() {return maxEnergy;}

    @Override
    public void attack(Character target) {
        // Normal attack if enough energy
        if (energy >= 10) {
            System.out.println(this.getName() + " slashes " + target.getName());
            target.takeDamage(this.getAttackDamage());
            energy -= 10;
        } else {
            // Weak attack if exhausted
            System.out.println(this.getName() + " has no energy! Uses weak attack.");
            int weakDamage = Math.max(0, this.getAttackDamage() - 10);
            target.takeDamage(weakDamage);
        }

        // Regenerate energy each turn
        if (energy < maxEnergy) {
            energy += 10;
            if (energy > maxEnergy) energy = maxEnergy;
        }
    }

    @Override
    public boolean specialAttack(Character target) {

        // Whirlwind Attack requires 20 energy
        if (energy >= 20) {
            System.out.println(this.getName() + " performs Whirlwind Attack!");
            target.takeDamage(this.getAttackDamage() + 15);
            energy -= 20;
            return true;
        } else {
            System.out.println(this.getName() + " doesn't have enough energy for a special attack!");
            return false;
        }
    }

    // Called during level up
    public void levelUpEnergy() {
        maxEnergy += 20; // Increase energy cap
        energy = maxEnergy; // Restore full energy
    }
}

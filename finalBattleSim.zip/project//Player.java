public abstract class Player extends Character {
    public Player(String name, int health, int attackDamage, int defense) {
        super(name, health, attackDamage, defense);
    }
}
